import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Phone, ShoppingCart, Mail, Star } from "lucide-react";

export default function HoppeApp() {
  return (
    <div className="min-h-screen bg-gray-50 text-gray-800">
      <header className="bg-white shadow p-6 flex items-center justify-between">
        <h1 className="text-3xl font-bold text-blue-900">Hoppe</h1>
        <Button variant="outline">
          <ShoppingCart className="mr-2" /> Keranjang
        </Button>
      </header>

      <section className="bg-blue-900 text-white py-16 px-6 text-center">
        <h2 className="text-4xl font-semibold mb-4">Selamat Datang di Hoppe</h2>
        <p className="text-lg max-w-2xl mx-auto">
          Toko online terpercaya untuk produk pilihan berkualitas. Temukan koleksi terbaik kami dan nikmati pengalaman belanja yang mudah.
        </p>
      </section>

      <section className="py-10 px-6">
        <h3 className="text-2xl font-bold mb-6 text-center">Katalog Produk</h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
          {[1, 2, 3].map((item) => (
            <Card key={item} className="hover:shadow-lg">
              <img
                src={`/produk${item}.jpg`}
                alt={`Produk ${item}`}
                className="rounded-t-xl w-full h-48 object-cover"
              />
              <CardContent className="p-4">
                <h4 className="font-semibold text-lg mb-2">Produk {item}</h4>
                <p className="text-sm mb-4">Deskripsi singkat produk {item}.</p>
                <Button className="w-full">Tambah ke Keranjang</Button>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      <section className="py-10 px-6 bg-white">
        <h3 className="text-2xl font-bold mb-6 text-center">Galeri Foto</h3>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
          {[1, 2, 3, 4].map((item) => (
            <img
              key={item}
              src={`/galeri${item}.jpg`}
              alt={`Galeri ${item}`}
              className="rounded-xl object-cover"
            />
          ))}
        </div>
      </section>

      <section className="py-10 px-6 bg-gray-100">
        <h3 className="text-2xl font-bold mb-6 text-center">Testimoni Pelanggan</h3>
        <div className="grid gap-6 md:grid-cols-2">
          {[1, 2].map((item) => (
            <Card key={item}>
              <CardContent className="p-4">
                <div className="flex items-center mb-2">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="text-yellow-400 mr-1" />
                  ))}
                </div>
                <p className="italic text-sm">"Pelayanannya cepat dan produknya bagus sekali!"</p>
                <p className="text-sm font-semibold mt-2">- Pelanggan {item}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      <section className="py-10 px-6 bg-white">
        <h3 className="text-2xl font-bold mb-6 text-center">Hubungi Kami</h3>
        <form className="max-w-xl mx-auto space-y-4">
          <Input placeholder="Nama Anda" required />
          <Input placeholder="Email Anda" type="email" required />
          <Textarea placeholder="Pesan" required rows={4} />
          <Button className="w-full">Kirim</Button>
        </form>
        <div className="text-center mt-6 text-sm text-gray-600">
          <Phone className="inline-block mr-1" /> <a href="https://wa.me/6285748731676" className="text-blue-700">085748731676</a>
        </div>
      </section>

      <footer className="bg-blue-900 text-white py-6 text-center mt-10">
        <p>&copy; 2025 Hoppe. All rights reserved.</p>
      </footer>
    </div>
  );
}
