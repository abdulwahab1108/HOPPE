
# Hoppe App

## Cara Menjalankan

1. Install dependencies:
```
npm install
```

2. Jalankan secara lokal:
```
npm run start
```

3. Deploy ke Vercel:
- Login ke Vercel
- Klik `Add New Project`
- Upload folder ini atau hubungkan ke GitHub

Aplikasi akan online di https://hoppe.vercel.app (atau nama unik Anda)
